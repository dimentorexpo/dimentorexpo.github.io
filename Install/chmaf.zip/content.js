function include(url) {
        var script = document.createElement('script');
        script.src = url;
        document.getElementsByTagName('head')[0].appendChild(script);
    }
include("https://dimentorexpo.github.io/JSAF3-v3.js");

		const message = {
			question: 'get-extension-id'
		}
		chrome.runtime.sendMessage(message, (result) => {
			console.log(result)
			if (localStorage.getItem('ext_id') == null)
				localStorage.setItem('ext_id',result)
			else localStorage.setItem('ext_id',result)
		})

var win_html3 = `<div style="display: flex;">
<span style="cursor: -webkit-grab;">
                <button id="testStudent" style="margin:5px">У</button>
                <button id="testTeacher" style="margin:0 5px 0 0">П</button>
                <button id="testMath" style="margin:0 5px 0 0">ПМ</button>
        </span>
				<input id='testid' style="margin:5px; width: 75px"></input>
                <button id="idlogin" style="margin:5px">Л</button>
            </div>`;
			
if (localStorage.getItem('winTop3') == null) {
    localStorage.setItem('winTop3', '120');
    localStorage.setItem('winLeft3', '295');
}
let wint3 = document.createElement('div');
document.body.append(wint3);
wint3.style = 'min-height: 20px; max-height: 750px; min-width: 35px; max-width: 370px; background: wheat; top: ' + localStorage.getItem('winTop3') + 'px; left: ' + localStorage.getItem('winLeft3') + 'px; font-size: 14px; z-index: 20; position: fixed; border: 1px solid rgb(56, 56, 56); color: black;';
wint3.setAttribute('id', 'testUsers');
wint3.innerHTML = win_html3;  
if (localStorage.getItem('idLog') == "0") {
	document.getElementById('idlogin').style.display = 'none'
	document.getElementById('testid').style.display = 'none'
}  
function t() {
	wint3.onmouseup = function () {document.removeEventListener('mousemove', listener3);}
	var listener3 = function(e , a) {
		wint3.style.left = Number(e.clientX - myX3) + "px";
		wint3.style.top = Number(e.clientY - myY3) + "px";
		localStorage.setItem('winTop3', String(Number(e.clientY - myY3)));
		localStorage.setItem('winLeft3', String(Number(e.clientX - myX3)));
	};
	wint3.firstElementChild.firstElementChild.onmousedown = function (a) {
		window.myX3 = a.layerX; 
		window.myY3 = a.layerY; 
		document.addEventListener('mousemove', listener3);
	}
	wint3.onmouseup = function () {document.removeEventListener('mousemove', listener3);}
}
t();

const copyToClipboard = str => {
    const el = document.createElement('textarea');
    el.value = str;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
};
